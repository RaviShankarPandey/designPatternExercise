package CH07.designpatterns.collections.iterator;

public interface Menu {
	public Iterator createIterator();
}
